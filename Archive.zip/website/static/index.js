function dismissAlert(button) {
    button.parentNode.remove();
}